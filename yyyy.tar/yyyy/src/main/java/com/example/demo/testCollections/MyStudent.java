package com.example.demo.testCollections;

public class MyStudent {
    public String name;
    public Integer score;

    public MyStudent(String name, Integer score) {
        this.name = name;
        this.score = score;
    }
}
