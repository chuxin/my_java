package com.example.demo.testAbstract;

import com.example.demo.testAbstract.Person;

public class Student extends Person {

    @Override
    public void run() {
        System.out.println("student.run");
    }
}
