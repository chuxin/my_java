package com.example.demo.testInterface;

public interface Hello {

    void hello();

}
