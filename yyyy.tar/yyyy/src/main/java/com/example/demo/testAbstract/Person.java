package com.example.demo.testAbstract;

public abstract class Person {

    public abstract void run();

}
