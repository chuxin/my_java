package com.example.demo.testStatic;

public interface StaticInterface {

    public static final int male = 1;

    int female = 2;         // 编译器会自动加上public statc final:

}
