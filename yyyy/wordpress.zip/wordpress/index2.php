<?php
include 'ImageHandler.php';
/**
 * 根据比例尺1来进行缩放
 * ①x<1&&y>1   y>x>1   高多
 * ②x>1&&y<1   x>y>1   宽多
 * ③x=y&&x>=1          等比例，但大于1
 * ④x<1&&y<1
 * ⑤x<42||y<42          宽或高拉至42
 */
$fileName = '2.jpg';
$url = "http://" . $_SERVER ['HTTP_HOST'] . '/photo/'.$fileName;
$temp = getimagesize($url);
$orgWidth = $temp[0];
$orgHeight = $temp[1];
$newArr = array(
    array('42', '42'),
    array('72', '72'),
    array('96', '96')
);
$newWidth = $newArr[2][0];
$newHeight = $newArr[2][1];

//计算尺寸
function calculateSize($orgWidth, $orgHeight, $newWidth, $newHeight) {
    $top        = 0;
    $left       = 0;
    $isExtraCal = false;
    if($newWidth != '' && $newHeight != '') {
        $isExtraCal = true;
    }
    //缩放比例
    $xRatio = $orgWidth / $newWidth;
    $yRatio = $orgHeight / $newHeight;
    if (((1 < $yRatio) && ($yRatio < $xRatio)) || (($xRatio >= 1) && ($yRatio <= 1))) { //宽多
        $srcWidth = 1 / $xRatio * $orgWidth;
        $srcHeight = 1 / $xRatio * $orgHeight;
    } else if ((($xRatio < $yRatio) && ($xRatio > 1)) || (($xRatio <= 1) && ($yRatio >= 1))) {//高多
        $srcWidth = 1 / $yRatio * $orgWidth;
        $srcHeight = 1 / $yRatio * $orgHeight;
    } else if ($xRatio == $yRatio && $xRatio >= 1) { //相等比例且大于原裁剪宽高
        $srcWidth = $newWidth;
        $srcHeight = $newHeight;
    } else if ($xRatio < 1 && $yRatio < 1) {  //宽高都小于原裁剪宽高
        $srcWidth = $orgWidth;
        $srcHeight = $orgHeight;
    }
    
    if($isExtraCal) {
        $top  = $newWidth >= $srcWidth   ? ($newWidth - $srcWidth)/2  : 0;   
        $left = $newHeight >= $srcHeight  ? ($newHeight - $srcHeight)/2 : 0;
    }
    return array($srcWidth, $srcHeight, $top, $left);
}

//按比例居中显示图片
function centerPositionPic($orgWidth, $orgHeight, $frameWidth='', $frameHeight='') {
    
}


$pathUrl = $_SERVER['DOCUMENT_ROOT'].'/photo/';
$paramsArrImage = array(
    'fileName'=>$fileName,
    'filePath'=>$pathUrl,
    'fileExt' => substr($fileName, strpos($fileName, '.') + 1),
    'fullPath' => $pathUrl.$fileName
);
/**
  *  按比例缩放图片
  * @param   array  $paramsArrImage          上传图片后返回的相关信息
  * @param   int    $width                   缩放后的宽
  * @param   int    $height                  缩放后的高
  * @return  boolean   true成功   false失败
  */
function imageResizer($paramsArrImage, $width, $height) {
    if (!is_array($paramsArrImage)) {
        return false;
    }
    if (!is_numeric($width) || ($width <= 0)) {
        return false;
    }
    if (!is_numeric($height) || ($height <= 0)) {
        return false;
    }
    $flag = true;
    extract($paramsArrImage);

    $prefix = $width . 'x' . $height . '_';
    $fileName = isset($fileName) && !empty($fileName) ? $fileName : ($flag = false);
    $filePath = isset($filePath) && !empty($filePath) ? $filePath : ($flag = false);
    $fileExt = isset($fileExt) && !empty($fileExt) ? $fileExt : ($flag = false);
    $fullPath = isset($fullPath) && !empty($fullPath) ? $fullPath : ($flag = false);
    if (!$flag) {
        return false;
    }
    $fileExt = ltrim($fileExt, '.');
    $filePath = $filePath . $prefix . $fileName;

    $ImageHandler = new ImageHandler($fullPath, $filePath, $fileExt);
    return $ImageHandler->createImg($width, $height);
}
?>

<!DOCTYPE html>
<html>
    <head>
        <style>

        </style>
    </head>
    <body>
        <?php 
            //裁剪尺寸预处理
//            $res = calculateSize($orgWidth, $orgHeight, $newWidth, $newHeight); 
            //尺寸裁剪
            $a = imageResizer($paramsArrImage, $newWidth, $newHeight);
            var_dump($a);
            //展示调用方法
            $newPath = $pathUrl.$newWidth.'x'.$newHeight.'_'. $fileName;    //相对路径
            $temp = getimagesize($newPath);
            $orgWidth = $temp[0];
            $orgHeight = $temp[1];
            $res2 = calculateSize($orgWidth, $orgHeight, '100', '100'); 
        ?>
        <div style="position:relative;border:2px solid #eee;width:<?php echo '100'; ?>px;height:<?php echo '100'; ?>px;">
            <img style="position:absolute;left:<?php echo $res2[2]; ?>px;top:<?php echo $res2[3]; ?>px;" width='<?php echo $res2[0]; ?>' height='<?php echo $res2[1]; ?>' src="<?php echo "http://" . $_SERVER ['HTTP_HOST'] . '/photo/'.$newWidth.'x'.$newHeight.'_'. $fileName; ?>" />
        </div>
    </body>
</html>
