<?php
/**
 * ͼƬ����������
 * @author chao.qian
 * @createdate 2014-5
 * @example 
 * <?php 
 * // ���Ե�Gifͷ��ͼƬ
 * $img = new ImageHandler("/usr/local/www/htdocs/style/default/img/abc.jpg","/usr/local/www/htdocs/style/default/img/abc.small.gif","gif");
 * $img->setCutType(2);
 * $img->setSrcCutPosition(50,100);
 * $img->setRectangleCut(80,80);
 * $img->createImg($img->getImgWidth(),$img->getImgHeight());
 * // ���������ߵȱ����޸�ͼƬ
 * $img = new ImageHandler("/usr/local/www/htdocs/style/default/img/img_el.png","/usr/local/www/htdocs/style/default/img/abctest.jpg","jpg");
 * $img->createImg(120,120);
 */
    class ImageHandler
    {
        private $dst_img;// Ŀ���ļ�     
        private $h_src; // ͼƬ��Դ���     
        private $h_dst;// ��ͼ���    
        private $h_mask;// ˮӡ���     
        private $img_create_quality = 100;// ͼƬ��������     
        private $img_display_quality = 80;// ͼƬ��ʾ����,Ĭ��Ϊ80     
        private $img_scale = 0;// ͼƬ���ű���     
        private $src_w = 0;// ԭͼ����    
        private $src_h = 0;// ԭͼ�߶�     
        private $dst_w = 0;// ��ͼ�ܿ���    
        private $dst_h = 0;// ��ͼ�ܸ߶�     
        private $fill_w;// ���ͼ�ο�     
        private $fill_h;// ���ͼ�θ�     
        private $copy_w;// ����ͼ�ο�     
        private $copy_h;// ����ͼ�θ�    
        private $src_x = 0;// ԭͼ������ʼ������     
        private $src_y = 0;// ԭͼ������ʼ������     
        private $start_x;// ��ͼ������ʼ������     
        private $start_y;// ��ͼ������ʼ������     
        private $mask_word;// ˮӡ����     
        private $mask_img;// ˮӡͼƬ     
        private $mask_pos_x = 0;// ˮӡ������     
        private $mask_pos_y = 0;// ˮӡ������    
        private $mask_offset_x = 5;// ˮӡ����ƫ��     
        private $mask_offset_y = 5;// ˮӡ����ƫ��    
        private $font_w;// ˮӡ�����     
        private $font_h;// ˮӡ�����     
        private $mask_w;// ˮӡ��     
        private $mask_h;// ˮӡ��     
        private $mask_font_color = "#ffffff";// ˮӡ������ɫ     
        private $mask_font = 2;// ˮӡ����    
        private $font_size;// �ߴ�    
        private $mask_position = 0;// ˮӡλ��     
        private $mask_img_pct = 50;// ͼƬ�ϲ��̶�,ֵԽ�󣬺ϲ�����Խ��     
        private $mask_txt_pct = 50;// ���ֺϲ��̶�,ֵԽС���ϲ�����Խ��     
        private $img_border_size = 0;// ͼƬ�߿�ߴ�     
        private $img_border_color;// ͼƬ�߿���ɫ     
        private $_flip_x=0;// ˮƽ��ת����     
        private $_flip_y=0;// ��ֱ��ת����       
        private $cut_type=0;// ��������         
        private $img_type;// �ļ�����       // �ļ����Ͷ���,��ָ�������ͼƬ�ĺ���     
        private $all_type = array(
                                "jpg"  => array("output"=>"imagejpeg"),
                                "gif"  => array("output"=>"imagegif"),
                                "png"  => array("output"=>"imagepng"),
                                "wbmp" => array("output"=>"image2wbmp"),
                                "jpeg" => array("output"=>"imagejpeg")
        ); 
        private static $pixelFix = 42;

        /**
         * ���캯��
         * @param string $p_strSrc ԴͼƬ·��
         * @param string $p_strDst ͼƬ����·��
         * @param string $img_type ͼƬ�������� Ĭ��Ϊ��
         */
        public function __construct($p_strSrc,$p_strDst,$img_type=null)
        {

                $this->mask_font_color = "#ffffff";
                $this->font = 2;
                $this->font_size = 12;

                $this->_setSrcImg($p_strSrc);

                $this->_setDstImg($p_strDst,$img_type);

        } 

        /**
         * ȡ��ͼƬ�Ŀ� 
         * @return int ͼƬ�Ŀ�
         */
        public function getImgWidth()
        {
                return imagesx($this->h_src);
        }

        /**
         * ȡ��ͼƬ�ĸ�
         * @return int ͼƬ�ĸ�
         */
        public function getImgHeight()
        {
                return imagesy($this->h_src);
        }

        /**
         * ����ԴͼƬ
         * @param string $src_img ԴͼƬ·��
         */
        private function _setSrcImg($src_img)
        {
                if(!file_exists($src_img))
                {
  
                        return false;
                }
                // file_get_contents����Ҫ��php�汾>4.3.0
                $src = '';
                if(function_exists("file_get_contents"))
                {
                        $src = file_get_contents($src_img);
                }
                else
                {
                        $handle = fopen ($src_img, "r");
                        while (!feof ($handle))
                        {
                                $src .= fgets($handle, 4096);
                        }
                        fclose ($handle);
                }
                if(empty($src))
                {
             
                        return false;
                }

                $this->h_src = @ImageCreateFromString($src);
                $this->src_w = $this->getImgWidth();
                $this->src_h = $this->getImgHeight();
                return true;
        }

        /**
         * ����ͼƬ����·��
         * @param string $dst_img ͼƬ����·��
         * @param string $img_type ͼƬ�������� Ĭ��Ϊ��
         */   
        private function _setDstImg($dst_img,$img_type=null)
        {
                if(!empty($img_type))
                {
                        $this->img_type = $img_type;
                }
                else
                {
                        $this->img_type = $this->_getImgType($dst_img);
                }
                $this->_checkValid($this->img_type);   
                $arr  = explode('/',$dst_img);
                $last = array_pop($arr);
                $path = implode('/',$arr);
                $this->_mkdirs($path);
                $this->dst_img = $dst_img;
        } 

        /**
         * ����ͼƬ����ʾ����
         * @param int $n ����
         */   
        public function setImgDisplayQuality($n)
        {
                $this->img_display_quality = (int)$n;
        }

        /**
         * ����ͼƬ����������
         * @param int $n ����
         */    
        public function setImgCreateQuality($n)
        {
                $this->img_create_quality = (int)$n;
        } 

        /**
         * ��������ˮӡ
         * @param string $word ˮӡ����
         */     
        public function setMaskWord($word)
        {
                $this->mask_word .= $word;
        }

        /**
         * ����������ɫ
         * @param string $color ������ɫ
         */   
        public function setMaskFontColor($color="#ffffff")
        {
                $this->mask_font_color = $color;
        } 

        /**
         * ����ˮӡ����
         * @param string|int $font ����
         */    
        public function setMaskFont($font=2)
        {
                if(!is_numeric($font) && !file_exists($font))
                {
                        //Log::addlog('ImageHandler[setMaskFont]', '�����ļ�������,����·��:'.$font);
                        return;
                }
                $this->font = $font;
        }

        /**
         * �������������С,����truetype������Ч
         * @param string $size �����С
         */
        public function setMaskFontSize($size = "12")
        {
                $this->font_size = $size;
        } 

        /**
         * ����ͼƬˮӡ
         * @param string $img ˮӡͼƬԴ
         */
        public function setMaskImg($img)
        {
                $this->mask_img = $img;
        }

        /**
         * ����ˮӡ����ƫ��
         * @param int $x ����ƫ����
         */   
        public function setMaskOffsetX($x)
        {
                $this->mask_offset_x = (int)$x;
        }

        /**
         * ����ˮӡ����ƫ��
         * @param int $y ����ƫ����
         */  
        public function setMaskOffsetY($y)
        {
                $this->mask_offset_y = (int)$y;
        }

        /**
         * ָ��ˮӡλ��
         * @param int $position λ��,1:����,2:����,3:����,0/4:����
         */   
        public function setMaskPosition($position=0)
        {
                $this->mask_position = (int)$position;
        } 

        /**
         * ����ͼƬ�ϲ��̶�
         * @param int $n �ϲ��̶�
         */
        public function setMaskImgPct($n)
        {
                $this->mask_img_pct = (int)$n;
        }

        /**
         * �������ֺϲ��̶�
         * @param int $n �ϲ��̶�   
         */
        public function setMaskTxtPct($n)
        {
                $this->mask_txt_pct = (int)$n;
        }

        /**
         * ��������ͼ�߿�
         * @param int $size �߿��С
         * @param string $color �߿���ɫ
         */   
        public function setDstImgBorder($size=1, $color="#000000")
        {
                $this->img_border_size  = (int)$size;
                $this->img_border_color = $color;
        }

        /**
         * ˮƽ��ת
         */
        public function flipH()
        {
                $this->_flip_x++;
        }

        /**
         * ��ֱ��ת
         */
        public function flipV()
        {
                $this->_flip_y++;
        }

        /**
         * ���ü�������
         * @param int $type �������� 0���������� 1���Զ����� 2���ֶ�����
         */   
        public function setCutType($type)
        {
                $this->cut_type = (int)$type;
        }

        /**
         * ����ͼƬ����
         * @param int $width ��
         * @param int $height ��
         */ 
        public function setRectangleCut($width, $height)
        {
                $this->fill_w = (int)$width;
                $this->fill_h = (int)$height;
        } 

        /**
         * ����Դͼ������ʼ�����
         * @param int $x ����ƫ����
         * @param int $y ����ƫ����
         */  
        public function setSrcCutPosition($x, $y)
        {
                $this->src_x  = (int)$x;
                $this->src_y  = (int)$y;
        } 

        /**
         *  ����ͼƬ,������
         * @param int $a ��ȱ�ٵڶ�������ʱ���˲����������ٷֱ�,������Ϊ����ֵ
         * @param int $b ͼƬ���ź�ĸ߶�
         * @return true �ɹ�  false ʧ��
         */  
        public function createImg($a, $b=null)
        { 
                $num = func_num_args();
                if(1 == $num)
                {
                        $r = (int)$a;
                        if($r < 1)
                        {
                                //Log::addlog('ImageHandler[createImg]', 'ͼƬ���ű�������С��1');
                                return false;
                        }
                        $this->img_scale = $r;
                        $this->_setNewImgSize($r);
                }

                if(2 == $num)
                {
                        $w = (int)$a;
                        $h = (int)$b;

                        if(0 == $w)
                        {
                                //Log::addlog('ImageHandler[createImg]', 'Ŀ����Ȳ���Ϊ0');
                                return false;
                        }
                        if(0 == $h)
                        {
                                //Log::addlog('ImageHandler[createImg]', 'Ŀ��߶Ȳ���Ϊ0');
                                return false;
                        }
                        $this->_setNewImgSize($w, $h);
                }
                if($this->_flip_x%2!=0)
                {
                        $this->_flipH($this->h_src);
                }

                if($this->_flip_y%2!=0)
                {
                        $this->_flipV($this->h_src);
                }
                if (!$this->_createMask()) return false;
                if (!$this->_output()) return false;           
                // �ͷ�
                if(imagedestroy($this->h_src) && imagedestroy($this->h_dst))
                {
                        Return true;
                }
                else
                {
                        Return false;
                }
        }

        /**
         * ����ˮӡ,����������ˮӡ���ֺ�ˮӡͼƬ��������
         */   
        private function _createMask()
        {
                if($this->mask_word)
                {
                        // ��ȡ������Ϣ
                        $this->_setFontInfo();
                        if($this->_isFull())
                        {
                                //Log::addlog('ImageHandler[_createMask]', 'ˮӡ���ֹ���');
                                return false;
                        }
                        else
                        {
                                $this->h_dst = imagecreatetruecolor($this->dst_w, $this->dst_h);
                                $white = ImageColorAllocate($this->h_dst,255,255,255);
                                imagefilledrectangle($this->h_dst,0,0,$this->dst_w,$this->dst_h,$white);	// ��䱳��ɫ
                                $this->_drawBorder();
                                imagecopyresampled( $this->h_dst, $this->h_src,
                                                                        $this->start_x, $this->start_y,
                                                                        $this->src_x, $this->src_y,
                                                                        $this->fill_w, $this->fill_h,
                                                                        $this->copy_w, $this->copy_h);
                                $this->_createMaskWord($this->h_dst);
                        }
                }
                if($this->mask_img)
                {
                        $this->_loadMaskImg();	//����ʱ��ȡ�ÿ���
                        if($this->_isFull())
                        {
                                // ��ˮӡ������ԭͼ���ٿ�
                                $this->_createMaskImg($this->h_src);
                                $this->h_dst = imagecreatetruecolor($this->dst_w, $this->dst_h);
                                $white = ImageColorAllocate($this->h_dst,255,255,255);
                                imagefilledrectangle($this->h_dst,0,0,$this->dst_w,$this->dst_h,$white);	// ��䱳��ɫ
                                $this->_drawBorder();
                                imagecopyresampled( $this->h_dst, $this->h_src,
                                                                        $this->start_x, $this->start_y,
                                                                        $this->src_x, $this->src_y,
                                                                        $this->fill_w, $this->start_y,
                                                                        $this->copy_w, $this->copy_h);
                        }
                        else
                        {
                                // ������ͼ������
                                $this->h_dst = imagecreatetruecolor($this->dst_w, $this->dst_h);
                                $white = ImageColorAllocate($this->h_dst,255,255,255);
                                imagefilledrectangle($this->h_dst,0,0,$this->dst_w,$this->dst_h,$white);	// ��䱳��ɫ
                                $this->_drawBorder();
                                imagecopyresampled( $this->h_dst, $this->h_src,
                                                                        $this->start_x, $this->start_y,
                                                                        $this->src_x, $this->src_y,
                                                                        $this->fill_w, $this->fill_h,
                                                                        $this->copy_w, $this->copy_h);
                                $this->_createMaskImg($this->h_dst);
                        }
                }
                if(empty($this->mask_word) && empty($this->mask_img))
                {
                        $this->h_dst = imagecreatetruecolor($this->dst_w, $this->dst_h);
                        $white = ImageColorAllocate($this->h_dst,255,255,255);
                        imagefilledrectangle($this->h_dst,0,0,$this->dst_w,$this->dst_h,$white);	// ��䱳��ɫ
                        $this->_drawBorder();
                        imagecopyresampled( $this->h_dst, $this->h_src,
                                                                $this->start_x, $this->start_y,
                                                                $this->src_x, $this->src_y,
                                                                $this->fill_w, $this->fill_h,
                                                                $this->copy_w, $this->copy_h);
                }
                return true;
        }

        /**
         * ���߿�
         */   
        private function _drawBorder()
        {
                if(!empty($this->img_border_size))
                {
                        $c = $this->_parseColor($this->img_border_color);
                        $color = ImageColorAllocate($this->h_src,$c[0], $c[1], $c[2]);
                        imagefilledrectangle($this->h_dst,0,0,$this->dst_w,$this->dst_h,$color);	// ��䱳��ɫ
                }
        }

        /**
         * ����ˮӡ����
         * @param object $src ͼ����
         */
        private function _createMaskWord($src)
        {
                $this->_countMaskPos();
                $this->_checkMaskValid();
                $c = $this->_parseColor($this->mask_font_color);
                $color = imagecolorallocatealpha($src, $c[0], $c[1], $c[2], $this->mask_txt_pct);
                if(is_numeric($this->font))
                {
                        imagestring($src,$this->font,$this->mask_pos_x,$this->mask_pos_y,$this->mask_word,$color);
                }
                else
                {
                        imagettftext($src,$this->font_size, 0,$this->mask_pos_x, $this->mask_pos_y,$color,$this->font,$this->mask_word);
                }
        }

        /**
         * ����ˮӡͼ 
         * @param object $src ͼ����
         */    
        private function _createMaskImg($src)
        {
                $this->_countMaskPos();
                $this->_checkMaskValid();
                imagecopymerge($src,$this->h_mask,$this->mask_pos_x ,$this->mask_pos_y,0, 0,$this->mask_w, $this->mask_h,$this->mask_img_pct);
                imagedestroy($this->h_mask);
        }

        /**
         * ����ˮӡͼ
         */
        private function _loadMaskImg()
        {
                $mask_type = $this->_getImgType($this->mask_img);
                $this->_checkValid($mask_type);
                // file_get_contents����Ҫ��php�汾>4.3.0
                $src = '';
                if(function_exists("file_get_contents"))
                {
                        $src = file_get_contents($this->mask_img);
                }
                else
                {
                        $handle = fopen ($this->mask_img, "r");
                        while (!feof ($handle))
                        {
                                $src .= fgets($handle, 4096);
                        }
                        fclose ($handle);
                }
                if(empty($this->mask_img))
                {
                        //Log::addlog('ImageHandler[_loadMaskImg]', 'ˮӡͼƬΪ��');
                }
                $this->h_mask = ImageCreateFromString($src);
                $this->mask_w = $this->getImgWidth($this->h_mask);
                $this->mask_h = $this->getImgHeight($this->h_mask);
        }

        /**
         * ͼƬ���
         */
        private function _output()
        {
            $img_type  = $this->img_type;
            $func_name = $this->all_type[$img_type]['output'];
            if (!function_exists($func_name)) return false;
            // �ж������,����IE�Ͳ�����ͷ
//            if(isset($_SERVER['HTTP_USER_AGENT']))
//            {
//                $ua = strtoupper($_SERVER['HTTP_USER_AGENT']);
//                if(!preg_match('/^.*MSIE.*\)$/i',$ua))
//                {
//                        header("Content-type:$img_type");
//                }
//            }
            if(in_array($img_type, array('jpg', 'jpeg'))) {
                @$func_name($this->h_dst, $this->dst_img, $this->img_display_quality);
            } else {
                @$func_name($this->h_dst, $this->dst_img);
            }
            return true;
        }

        /**
         * ������ɫ
         * @param string $color ʮ��������ɫ 
         */
        private function _parseColor($color)
        {
                $arr = array();
                for($ii=1; $ii<strlen ($color); $ii++)
                {
                        $arr[] = hexdec(substr($color,$ii,2));
                        $ii++;
                }
                Return $arr;
        }

        /**
         * �����λ������
         */
        private function _countMaskPos()
        {
                if($this->_isFull())
                {
                        switch($this->mask_position)
                        {
                                case 1:		// ����
                                        $this->mask_pos_x = $this->mask_offset_x + $this->img_border_size;
                                        $this->mask_pos_y = $this->mask_offset_y + $this->img_border_size;
                                        break;
                                case 2:		// ����
                                        $this->mask_pos_x = $this->mask_offset_x + $this->img_border_size;
                                        $this->mask_pos_y = $this->src_h - $this->mask_h - $this->mask_offset_y;
                                        break;
                                case 3:		// ����
                                        $this->mask_pos_x = $this->src_w - $this->mask_w - $this->mask_offset_x;
                                        $this->mask_pos_y = $this->mask_offset_y + $this->img_border_size;
                                        break;
                                default:	// Ĭ�Ͻ�ˮӡ�ŵ�����,ƫ��ָ������
                                        $this->mask_pos_x = $this->src_w - $this->mask_w - $this->mask_offset_x;
                                        $this->mask_pos_y = $this->src_h - $this->mask_h - $this->mask_offset_y;
                                        break;
                        }
                }
                else
                {
                        switch($this->mask_position)
                        {
                                case 1:		// ����
                                        $this->mask_pos_x = $this->mask_offset_x + $this->img_border_size;
                                        $this->mask_pos_y = $this->mask_offset_y + $this->img_border_size;
                                        break;
                                case 2:		// ����
                                        $this->mask_pos_x = $this->mask_offset_x + $this->img_border_size;
                                        $this->mask_pos_y = $this->dst_h - $this->mask_h - $this->mask_offset_y - $this->img_border_size;
                                        break;
                                case 3:		// ����
                                        $this->mask_pos_x = $this->dst_w - $this->mask_w - $this->mask_offset_x - $this->img_border_size;
                                        $this->mask_pos_y = $this->mask_offset_y + $this->img_border_size;
                                        break;
                                default:	// Ĭ�Ͻ�ˮӡ�ŵ�����,ƫ��ָ������
                                        $this->mask_pos_x = $this->dst_w - $this->mask_w - $this->mask_offset_x - $this->img_border_size;
                                        $this->mask_pos_y = $this->dst_h - $this->mask_h - $this->mask_offset_y - $this->img_border_size;
                                        break;
                        }
                }
        }

        /**
         * ����������Ϣ
         */
        private function _setFontInfo()
        {
                if(is_numeric($this->font))
                {
                        $this->font_w  = imagefontwidth($this->font);
                        $this->font_h  = imagefontheight($this->font);
                        // ����ˮӡ������ռ����
                        $word_length   = strlen($this->mask_word);
                        $this->mask_w  = $this->font_w*$word_length;
                        $this->mask_h  = $this->font_h;
                }
                else
                {
                        $arr = imagettfbbox ($this->font_size,0, $this->font,$this->mask_word);
                        $this->mask_w  = abs($arr[0] - $arr[2]);
                        $this->mask_h  = abs($arr[7] - $arr[1]);
                }
        }

        /**
         * ������ͼ�ߴ�
         * @param int $img_w Ŀ�����
         * @param int $img_h Ŀ��߶�
         */
        private function _setNewImgSize($img_w, $img_h=null)
        {
                $num = func_num_args();
                if(1 == $num)
                {
                        $this->img_scale = $img_w;// ������Ϊ����
                        $this->fill_w = round($this->src_w * $this->img_scale / 100) - $this->img_border_size*2;
                        $this->fill_h = round($this->src_h * $this->img_scale / 100) - $this->img_border_size*2;
                        // Դ�ļ���ʼ����
                        $this->src_x  = 0;
                        $this->src_y  = 0;
                        $this->copy_w = $this->src_w;
                        $this->copy_h = $this->src_h;
                        // Ŀ��ߴ�
                        $this->dst_w   = $this->fill_w + $this->img_border_size*2;
                        $this->dst_h   = $this->fill_h + $this->img_border_size*2;
                }
                if(2 == $num)
                {
                        $fill_w   = (int)$img_w - $this->img_border_size*2;
                        $fill_h   = (int)$img_h - $this->img_border_size*2;
                        if($fill_w < 0 || $fill_h < 0)
                        {
                                //Log::addlog('ImageHandler[_setNewImgSize]', 'ͼƬ�߿�����ѳ�����ͼƬ�Ŀ���');
                        }
                        $rate_w = $this->src_w/$fill_w;
                        $rate_h = $this->src_h/$fill_h;
                        switch($this->cut_type)
                        {
                                case 0:		// ���ԭͼ��������ͼ��������С��������С
                                        if($rate_w < 1 && $rate_h < 1)
                                        {
                                                $this->fill_w = (int)$this->src_w;
                                                $this->fill_h = (int)$this->src_h;
                                        }
                                        else
                                        {
                                                if($rate_w >= $rate_h)
                                                {
                                                        $this->fill_w = (int)$fill_w;
                                                        $this->fill_h = round($this->src_h/$rate_w);
                                                }
                                                else
                                                {
                                                        $this->fill_w = round($this->src_w/$rate_h);
                                                        $this->fill_h = (int)$fill_h;
                                                }
                                        }
                                        $this->src_x  = 0;
                                        $this->src_y  = 0;
                                        $this->copy_w = $this->src_w;
                                        $this->copy_h = $this->src_h;
                                        // Ŀ��ߴ�
                                        $this->dst_w  = $this->fill_w + $this->img_border_size*2;
                                        $this->dst_h  = $this->fill_h + $this->img_border_size*2;
                                        break;
                                case 1:		// �Զ����� ���ͼƬ����С���вŽ��в���
                                        if($rate_w >= 1 && $rate_h >=1)
                                        {
                                                if($this->src_w > $this->src_h)
                                                {
                                                        $src_x = round($this->src_w-$this->src_h)/2;
                                                        $this->setSrcCutPosition($src_x, 0);
                                                        $this->setRectangleCut($fill_h, $fill_h);
                                                        $this->copy_w = $this->src_h;
                                                        $this->copy_h = $this->src_h;
                                                }
                                                elseif($this->src_w < $this->src_h)
                                                {                             
                                                        $src_y = round($this->src_h-$this->src_w)/2;
                                                        $this->setSrcCutPosition(0, $src_y);
                                                        $this->setRectangleCut($fill_w, $fill_h);
                                                        $this->copy_w = $this->src_w;
                                                        $this->copy_h = $this->src_w;
                                                }
                                                else
                                                {
                                                        $this->setSrcCutPosition(0, 0);
                                                        $this->copy_w = $this->src_w;
                                                        $this->copy_h = $this->src_w;
                                                        $this->setRectangleCut($fill_w, $fill_h);
                                                }
                                        }
                                        else
                                        {
                                                $this->setSrcCutPosition(0, 0);
                                                $this->setRectangleCut($this->src_w, $this->src_h);
                                                $this->copy_w = $this->src_w;
                                                $this->copy_h = $this->src_h;
                                        }
                                        // Ŀ��ߴ�
                                        $this->dst_w  = $this->fill_w + $this->img_border_size*2;
                                        $this->dst_h  = $this->fill_h + $this->img_border_size*2;
                                        break;
                                case 2:		// �ֹ�����
                                        $this->copy_w = $this->fill_w;
                                        $this->copy_h = $this->fill_h;
                                        // Ŀ��ߴ�
                                        $this->dst_w  = $this->fill_w + $this->img_border_size*2;
                                        $this->dst_h   = $this->fill_h + $this->img_border_size*2;
                                        break;
                                default:
                                        break;
                        }
                }
                // Ŀ���ļ���ʼ����
                $this->start_x = $this->img_border_size;
                $this->start_y = $this->img_border_size;
        }

        /**
         * ���ˮӡͼ�Ƿ�������ɺ��ͼƬ����
         */
        private function _isFull()
        {
                Return ($this->mask_w + $this->mask_offset_x > $this->fill_w || $this->mask_h + $this->mask_offset_y > $this->fill_h)?true:false;
        }

        /**
         * ���ˮӡͼ�Ƿ񳬹�ԭͼ
         */
        private function _checkMaskValid()
        {
                if(    $this->mask_w + $this->mask_offset_x > $this->src_w || $this->mask_h + $this->mask_offset_y > $this->src_h)
                {
                        //Log::addlog('ImageHandler[_checkMaskValid]', 'ˮӡͼƬ�ߴ����ԭͼ������Сˮӡͼ');
                }     
        }

        /**
         * ȡ��ͼƬ���� 
         * @param string $file_path �ļ�·��
         */
        private function _getImgType($file_path)
        {
                $type_list = array("1"=>"gif","2"=>"jpg","3"=>"png","4"=>"swf","5" => "psd","6"=>"bmp","15"=>"wbmp");
                if(file_exists($file_path))
                {
                        $img_info = @getimagesize ($file_path);
                        if(isset($type_list[$img_info[2]]))
                        {
                                Return $type_list[$img_info[2]];
                        }
                }
                else
                {
                        //Log::addlog('ImageHandler[_getImgType]', '�ļ�������,����ȡ���ļ�����!');
                }
        }

        /**
         * ���ͼƬ�����Ƿ�Ϸ�,������array_key_exists�������˺���Ҫ��      * php�汾����4.1.0
         * @param string $img_type �ļ�����
         */     
        private function _checkValid($img_type)
        {
                if(!array_key_exists($img_type, $this->all_type))
                {
                        //Log::addlog('ImageHandler[_checkValid]', 'ͼƬ���Ͳ��Ϸ���ͼƬ���� ��'.$img_type);
                        Return false;
                }
        }

        /**
         * ��ָ��·������Ŀ¼
         * @param string $path ·�� 
         */
        private function _mkdirs($path)
        {
                $adir = explode('/',$path);
                $dirlist = '';
                $rootdir = array_shift($adir);
                if(($rootdir!='.'||$rootdir!='..')&&!file_exists($rootdir))
                {
                        @mkdir($rootdir);
                }
                foreach($adir as $key=>$val)
                {
                        if($val!='.'&&$val!='..')
                        {
                                $dirlist .= "/".$val;
                                $dirpath = $rootdir.$dirlist;
                                if(!file_exists($dirpath))
                                {
                                        @mkdir($dirpath);
                                        @chmod($dirpath,0777);
                                }
                        }
                }
        }

        /**
         * ��ֱ��ת
         * @param string $src ͼƬԴ
         */
        private function _flipV($src)
        {
                $src_x = $this->getImgWidth($src);
                $src_y = $this->getImgHeight($src);
                $new_im = imagecreatetruecolor($src_x, $src_y);
                for ($y = 0; $y < $src_y; $y++)
                {
                        imagecopy($new_im, $src, 0, $src_y - $y - 1, 0, $y, $src_x, 1);
                }
                $this->h_src = $new_im;
        }

        /**
         * ˮƽ��ת
         * @param string $src ͼƬԴ 
         */
        private function _flipH($src)
        {
                $src_x = $this->getImgWidth($src);
                $src_y = $this->getImgHeight($src);
                $new_im = imagecreatetruecolor($src_x, $src_y);
                for ($x = 0; $x < $src_x; $x++)
                {
                        imagecopy($new_im, $src, $src_x - $x - 1, 0, $x, 0, 1, $src_y);
                }
                $this->h_src = $new_im;
        }
        
        /**
        * ���ܣ���ԭͼ���ʵ��������ţ��γ�����ͼ���ָ��û���
        * @param   $divWidth       integer     ԭͼ���DIV����
        * @param   $divHeight      integer     ԭͼ���DIV�߶�
        * @param   $picFullPath    string      �ϴ�ͼƬ·��
        * @return  һά����          mix         1.��false��ʾͼƬ���Ͳ�֧�֣��޷���ʾ      �ڻ�ȡͼƬ���߲��Ǵ���0������
        *                                        2.array��ʾͼƬ���ź�Ŀ��͸�
        */
       public static function resizePic($divWidth, $divHeight, $picFullPath) {
           $pathArr = pathinfo($picFullPath);
           switch (strtolower($pathArr["extension"])) {
               case "jpg":
               case "jpeg":
                   //��ȡһ��ͼƬ��ȫ����Ϣ
                   $image2 = imagecreatefromjpeg($picFullPath);
                   break;
               case "gif":
                   $image2 = imagecreatefromgif($picFullPath);
                   break;
               case "png":
                   $image2 = imagecreatefrompng($picFullPath);
                   break;
               case "bmp":
                   $image2 = self::ImageCreateFromBMP($picFullPath);
                   break;
               default :
                   return false;
           }
           //ͼƬ����
           $image2x = @imagesx($image2);
           $image2y = @imagesy($image2);
           if(!is_numeric($image2x) || ($image2x <= 0) || !is_numeric($image2y) || ($image2y <= 0)) {
               return false;
           }
           //���ű���
           $xRatio = $image2x / $divWidth;
           $yRatio = $image2y / $divHeight;
           /*
            * ���ݱ�����1����������
            * ��x<1&&y>1   y>x>1   �߶�
            * ��x>1&&y<1   x>y>1   ����
            * ��x=y&&x>=1          �ȱ�����������1
            * ��x<1&&y<1
            * ��x<42||y<42          ���������42
            */
           if (((1 < $yRatio) && ($yRatio < $xRatio)) || (($xRatio >= 1) && ($yRatio <= 1))) {
               $srcWidth = 1/$xRatio * $image2x;
               $srcHeight = 1/$xRatio * $image2y;
           } else if ((($xRatio < $yRatio) && ($xRatio > 1)) || (($xRatio <= 1) && ($yRatio >= 1))) {
               $srcWidth = 1/$yRatio * $image2x;
               $srcHeight = 1/$yRatio * $image2y;
           } else if($xRatio == $yRatio && $xRatio>=1) {
               $srcWidth = $divWidth;
               $srcHeight = $divHeight;
           } else if($xRatio<1&&$yRatio<1) {
               $srcWidth = $image2x;
               $srcHeight = $image2y;
           }
           $srcHeight = $srcHeight < self::$pixelFix ? self::$pixelFix : $srcHeight;
           $srcWidth  = $srcWidth  < self::$pixelFix ? self::$pixelFix : $srcWidth;
           return array('srcWidth' => round($srcWidth), 'srcHeight' => round($srcHeight));
       }
       
        /**
        * @description      ����BMPͼƬ
        * @param   string    $bmpFilePath       �û��ϴ���ͼƬ·��
        * @return  resource  $image             ͼƬ���ݼ�                         ������������������������������������
        */
       public static function ImageCreateFromBMP($bmpFilePath) {
           $file = fopen($bmpFilePath, "rb");
           $read = fread($file, 10);
           while (!feof($file) && ($read <> ""))
               $read .= fread($file, 1024);
           $temp = @unpack("H*", $read);             //��ѹ��λ�ַ���    http://www.cnblogs.com/wanzibox/articles/1283110.html
           $hex = $temp[1];
           $header = substr($hex, 0, 108);
           if (substr($header, 0, 4) == "424d") {
               $header_parts = str_split($header, 2);
               $width = hexdec($header_parts[19] . $header_parts[18]);
               $height = hexdec($header_parts[23] . $header_parts[22]);
               unset($header_parts);
           }
           $x = 0;
           $y = 1;
           $image = @imagecreatetruecolor($width, $height);
           $body = substr($hex, 108);
           $body_size = (strlen($body) / 2);
           $header_size = ($width * $height);
           $usePadding = ($body_size > ($header_size * 3) + 4);
           for ($i = 0; $i < $body_size; $i+=3) {
               if ($x >= $width) {
                   if ($usePadding)
                       $i += $width % 4;
                   $x = 0;
                   $y++;
                   if ($y > $height)
                       break;
               }
               $i_pos = $i * 2;
               $r = hexdec($body[$i_pos + 4] . $body[$i_pos + 5]);
               $g = hexdec($body[$i_pos + 2] . $body[$i_pos + 3]);
               $b = hexdec($body[$i_pos] . $body[$i_pos + 1]);
               $color = @imagecolorallocate($image, $r, $g, $b);
               @imagesetpixel($image, $x, $height - $y, $color);
               $x++;
           }
           unset($body);
           return $image;
       }
	}

?>